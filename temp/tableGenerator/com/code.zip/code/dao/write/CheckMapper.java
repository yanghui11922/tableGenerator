
package com.code.dao.write;
import java.util.*;
import com.code.config.mybatis.MyMapper;
import com.code.domain.Check;

/**
 * <p> Mapper Class</p>
 *
 * @author majian
 * 
 */
public interface CheckMapper extends MyMapper<Check>{

}
